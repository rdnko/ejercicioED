package ejercicio03;

public interface Mascota {
	
	public void setNombre(String nombre);
	
	public String getNombre();
	
	public void jugar();

}
