package ejercicio04;

public class Encriptador {
	
	

}
