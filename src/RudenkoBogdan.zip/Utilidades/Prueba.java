package Utilidades;

public class Prueba {

	public static void main(String[] args) {
		// TODO Ap�ndice de m�todo generado autom�ticamente

		int aray []	= {4,2,5,7,1};
		//Organizar.organizarInt(aray);
		
		//Organizar.organizarIntSeleccion(aray);
		
		Organizar.organizarIntInsercion(aray);
		
		Organizar.mostrarInt(aray);
		
		
		
	}

}
